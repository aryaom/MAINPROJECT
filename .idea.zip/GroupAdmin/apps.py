from django.apps import AppConfig


class GroupadminConfig(AppConfig):
    name = 'GroupAdmin'
