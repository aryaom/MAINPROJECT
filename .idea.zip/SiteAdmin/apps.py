from django.apps import AppConfig


class SiteadminConfig(AppConfig):
    name = 'SiteAdmin'
