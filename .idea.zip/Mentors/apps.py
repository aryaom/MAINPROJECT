from django.apps import AppConfig


class MentorsConfig(AppConfig):
    name = 'Mentors'
